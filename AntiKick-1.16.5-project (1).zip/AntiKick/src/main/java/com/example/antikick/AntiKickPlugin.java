package com.example.antikick;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class AntiKickPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(new KickListener(this), this);

        if (getConfig().getBoolean("reset-vanilla-idle-timer", true)) {
            Bukkit.getScheduler().runTaskTimer(this, () -> {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (!player.hasPermission("antikick.bypass")) {
                        player.resetIdleTime();
                    }
                }
            }, 600L, 600L);
        }

        getLogger().info("AntiKick (только AFK) включен!");
    }

    @Override
    public void onDisable() {
        getLogger().info("AntiKick выключен!");
    }
}
