package com.example.antikick;

import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerKickEvent;

import java.util.List;

public class KickListener implements Listener {

    private final AntiKickPlugin plugin;

    public KickListener(AntiKickPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerKick(PlayerKickEvent event) {
        if (event.getPlayer().hasPermission("antikick.bypass")) {
            return;
        }

        String rawReason = event.getReason();
        if (rawReason == null || rawReason.isEmpty()) {
            return;
        }

        String plainReason = ChatColor.stripColor(rawReason).toLowerCase();
        List<String> afkKeywords = plugin.getConfig().getStringList("afk-kick-reasons");

        boolean isAfkKick = false;
        for (String keyword : afkKeywords) {
            if (keyword != null && !keyword.isEmpty() && plainReason.contains(keyword.toLowerCase())) {
                isAfkKick = true;
                break;
            }
        }

        if (!isAfkKick) {
            return;
        }

        event.setCancelled(true);
        event.getPlayer().resetIdleTime();

        if (plugin.getConfig().getBoolean("log-blocked-kicks", true)) {
            plugin.getLogger().info(
                "Отменён AFK-кик игрока " + event.getPlayer().getName() +
                " | Причина: " + rawReason
            );
        }
    }
}
